﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblLimit = New System.Windows.Forms.Label()
        Me.lblClocked = New System.Windows.Forms.Label()
        Me.lblLegal = New System.Windows.Forms.Label()
        Me.lblFine = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtLimit = New System.Windows.Forms.TextBox()
        Me.txtClocked = New System.Windows.Forms.TextBox()
        Me.txtLegal = New System.Windows.Forms.TextBox()
        Me.txtFine = New System.Windows.Forms.TextBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblLimit
        '
        Me.lblLimit.AutoSize = True
        Me.lblLimit.Location = New System.Drawing.Point(30, 32)
        Me.lblLimit.Name = "lblLimit"
        Me.lblLimit.Size = New System.Drawing.Size(141, 17)
        Me.lblLimit.TabIndex = 0
        Me.lblLimit.Text = "Enter the speed limit:"
        '
        'lblClocked
        '
        Me.lblClocked.AutoSize = True
        Me.lblClocked.Location = New System.Drawing.Point(30, 108)
        Me.lblClocked.Name = "lblClocked"
        Me.lblClocked.Size = New System.Drawing.Size(165, 17)
        Me.lblClocked.TabIndex = 1
        Me.lblClocked.Text = "Enter the clocked speed:"
        '
        'lblLegal
        '
        Me.lblLegal.AutoSize = True
        Me.lblLegal.Location = New System.Drawing.Point(6, 20)
        Me.lblLegal.Name = "lblLegal"
        Me.lblLegal.Size = New System.Drawing.Size(133, 17)
        Me.lblLegal.TabIndex = 2
        Me.lblLegal.Text = "The clocked time is:"
        '
        'lblFine
        '
        Me.lblFine.AutoSize = True
        Me.lblFine.Location = New System.Drawing.Point(6, 96)
        Me.lblFine.Name = "lblFine"
        Me.lblFine.Size = New System.Drawing.Size(39, 17)
        Me.lblFine.TabIndex = 3
        Me.lblFine.Text = "Fine:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtLegal)
        Me.GroupBox1.Controls.Add(Me.txtFine)
        Me.GroupBox1.Controls.Add(Me.lblFine)
        Me.GroupBox1.Controls.Add(Me.lblLegal)
        Me.GroupBox1.Location = New System.Drawing.Point(249, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(212, 171)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        '
        'txtLimit
        '
        Me.txtLimit.Location = New System.Drawing.Point(33, 70)
        Me.txtLimit.Name = "txtLimit"
        Me.txtLimit.Size = New System.Drawing.Size(100, 22)
        Me.txtLimit.TabIndex = 5
        '
        'txtClocked
        '
        Me.txtClocked.Location = New System.Drawing.Point(33, 140)
        Me.txtClocked.Name = "txtClocked"
        Me.txtClocked.Size = New System.Drawing.Size(100, 22)
        Me.txtClocked.TabIndex = 6
        '
        'txtLegal
        '
        Me.txtLegal.Location = New System.Drawing.Point(9, 58)
        Me.txtLegal.Name = "txtLegal"
        Me.txtLegal.ReadOnly = True
        Me.txtLegal.Size = New System.Drawing.Size(100, 22)
        Me.txtLegal.TabIndex = 7
        '
        'txtFine
        '
        Me.txtFine.Location = New System.Drawing.Point(9, 128)
        Me.txtFine.Name = "txtFine"
        Me.txtFine.ReadOnly = True
        Me.txtFine.Size = New System.Drawing.Size(100, 22)
        Me.txtFine.TabIndex = 8
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(33, 190)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(162, 43)
        Me.btnCalculate.TabIndex = 7
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(249, 190)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(162, 43)
        Me.btnReset.TabIndex = 8
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(478, 245)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtClocked)
        Me.Controls.Add(Me.txtLimit)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.lblClocked)
        Me.Controls.Add(Me.lblLimit)
        Me.Name = "Form1"
        Me.Text = "Speeding Fine Calculator"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblLimit As Label
    Friend WithEvents lblClocked As Label
    Friend WithEvents lblLegal As Label
    Friend WithEvents lblFine As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtLegal As TextBox
    Friend WithEvents txtFine As TextBox
    Friend WithEvents txtLimit As TextBox
    Friend WithEvents txtClocked As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnReset As Button
End Class
